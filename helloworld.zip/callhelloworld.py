import hello_world
import helloworld

hello_world.hello()
helloworld.hello()
